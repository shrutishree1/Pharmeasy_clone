# Pharmeasy
This is the Construct Week Group Project of PharmEasy clone using HTML CSS and JavaScript.

TOPIC STATEMENT

The working clone of "Take it easy, Pharmeasy", which delivers medicines and other healthcare items, now available via prescriptions. To build this clone we have used HTML5, CSS3, Advanced Javascript. Alongside doing this project, we learnt a lot of new things about team work, proper coordination and thinking along with all the team members. This was our first basic project using basic tools at Masai School. More amazing projects to come ..😊

DEPLOYED LINK
https://bejewelled-bubblegum-fa2cba.netlify.app/

STEPS FOLLOWED

1. We have to Open index.html file on the live server(using VS code live server)
2. On landing page User have to click on Login
3. The user gets 2 ways to add the product to the cart one by searching the required product name in the search bar of the landing page
4. Another way of adding products to the cart is by clicking on health-care products, a list of categories will be opened
5. On clicking any categories a filter page opens, a list of products related to that category appears
Products can be sorted from low to high or high to low, on sidebar products can be selected based on price range
6. On clicking any of the products, product detail page appears, from there the user can add it to the cart and the number of products added to the cart will be shown at the top of the view cart
7. On clicking veiw cart selected items will be shown
8. Users now can click on proceed to pay the button it will redirect to the payment page. After selecting the payment mode click on the place order
9. Now the order is placed. and by clicking on back to home it will take to a landing page
10. We have also added Footer in all the Pages
11. And we have also added some little functionality which you can check by opening the Page.

FUNCTIONALITIES IMPLEMENTED

1. Login via OTP verification
2. Search Engine
3. Shows the Products searched for
4. Can directly add to cart from here
5. Filter Products based on Sorting
6. Products
7. Availability
8. Product Names
9. Add selected product to cart
10. In Cart
11. Select the Quantity, cart value to be modified Accordingly
12. Delete the Product, if not required
13. Order Details
14. Amount to be Paid
15 .Available Payment Modes Shown in the Payment

Take it Easy and GO TO OUR PHARMEASY !!
